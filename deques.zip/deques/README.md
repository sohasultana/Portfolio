# Deques

An introduction to data structures and algorithm analysis through a comparison of double-ended queue implementations. See the [**Releases**](https://github.com/kevinlin1/deques/releases) for instructions.

## Setup

This project is pre-configured for IntelliJ IDEA.

1. Install [IntelliJ IDEA](https://www.jetbrains.com/idea/download/).
1. Download or clone this project and open it in IntelliJ.
1. Run the `BrowserHistory` class to try-out the default implementation.
